#! /bin/bash

basename "$BASH_SOURCE"
